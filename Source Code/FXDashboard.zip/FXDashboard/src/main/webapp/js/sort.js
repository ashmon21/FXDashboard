/* Custom Sort to sort numeric values with currency ltters */
$.fn.dataTableExt.oSort['currency-string-asc']  = function(x,y) {
	alert(x);
   	return ((x < y) ? -1 : ((x > y) ?  1 : 0));
};

$.fn.dataTableExt.oSort['currency-string-desc'] = function(x,y) {
   	return ((x < y) ?  1 : ((x > y) ? -1 : 0));
};
