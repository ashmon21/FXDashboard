$.fn.dataTableExt.oSort['currency-string-asc'] = function(a, b) {
	var x = stripStr(a), y = stripStr(b);
	return ((x < y) ? -1 : ((x > y) ? 1 : 0));
};

$.fn.dataTableExt.oSort['currency-string-desc'] = function(a, b) {
	var x = stripStr(a), y = stripStr(b);
	return ((x < y) ? 1 : ((x > y) ? -1 : 0));
};

function stripStr(x) {
	return parseFloat(x.replace(/[^\d\.\-]/g, ""));
};

$(document).ready(function() {

	$("#based").SumoSelect({});
	$("#wanted").SumoSelect({
		okCancelInMulti : true,
		captionFormatAllSelected : 'ALL SELECTED',
		captionFormat : '{0} SELECT',
		selectAll : true,
		triggerChangeCombined : false,
		csvDispCount : 3
	});
	$("#stats").SumoSelect({
		okCancelInMulti : true,
		captionFormatAllSelected : "<i class='fa fa-bars'></i>",
		captionFormat : "<i class='fa fa-bars'></i>",
		selectAll : true,
		floatWidth : 200,
		triggerChangeCombined : true,
		csvDispCount : 1
	});

});

function filterStats(elm) {
	var arr = $(elm).val();
	$.each($("#dataTable").find("tfoot").find("tr"), function() {
		var id = $(this).attr("id");
		if (id && $.inArray(id, arr) < 0) {
			$(this).hide();
		} else {
			$(this).show();
		}
	});
}

function toCurrency(num, cur) {
	var str = parseFloat(num, 10).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g,
			"$1,").toString();

	var x = cur ? str + " " + cur : str;

	return x;
}

function load() {
	var based = $("#based option:selected").val(), wanted = $("#wanted").val();

	if (based == 0) {
		alert("Please choose one based currency to extract data for.");
		return;
	}

	$.get("getBlotterData", {
		based : based,
		wanted : wanted + ""
	}, function(data) {
		setTable(data);
	}).fail(function() {
		alert("Error getting data");
	});
}

function setTable(data) {

	var tbl = $('#dataTable').dataTable({
		aaData : data,
		bDestroy : true,
		bAutoWidth : false,
		bJQueryUI : true,
		lengthMenu : [ [ 5, 10, 15, -1 ], [ 5, 10, 15, "All" ] ],
		aoColumnDefs : [ {
			bSortable : false,
			targets : 0
		}, {
			targets : [ 3 ],
			sType : 'currency-string',
			render : function(data, type, row) {
				return toCurrency(data, row[1]);
			}
		}, {
			targets : [ 6 ],
			sType : 'currency-string',
			render : function(data, type, row) {
				return toCurrency(data, row[2]);
			}
		}, {
			targets : [ 7 ],
			sType : 'currency-string',
			render : function(data, type, row) {
				return toCurrency(data, 'SGD');
			}
		} ],
		initComplete : function() {
			initTable(this);
		}
	});

	$("#dataTable").show();
	$("#stats_cnt").show();

	filterStats($("#stats"));
}

function initTable(table) {
	table.api().columns('.sum').every(function() {
		var column = this, idx = column.index() + 1, d = 0;

		if (this.data().length > 0) {
			var sum = column.data().reduce(function(a, b) {
				return parseFloat(a, 10) + parseFloat(b, 10);
			});

			var d = getStatsDisplay(idx, sum);
		}

		$("#sum th:nth-child(" + idx + ")").html(d);
	});

	table
			.api()
			.columns('.average')
			.every(
					function() {
						var column = this, idx = column.index() + 1, d = 0;

						if (this.data().length > 0) {
							sum = column.data().reduce(function(a, b) {
								return parseFloat(a, 10) + parseFloat(b, 10);
							});

							var avg = (sum / column.data().length).toFixed(4), d = getStatsDisplay(
									idx, avg);
						}

						$("#average th:nth-child(" + idx + ")").html(d);
					});

	table.api().columns('.max').every(
			function() {
				var column = this, idx = column.index() + 1, d = 0;

				if (this.data().length > 0) {
					var max = column.data().reduce(
							function(a, b) {
								return Math.max(parseFloat(a, 10),
										parseFloat(b, 10)).toFixed(4);
							}), d = getStatsDisplay(idx, max);
				}

				$("#max th:nth-child(" + idx + ")").html(d);
			});

	table.api().columns('.min').every(function() {
		var column = this, idx = column.index() + 1, d = 0;

		if (this.data().length > 0) {
			var min = column.data().reduce(function(a, b) {
				return Math.min(parseFloat(a, 10), parseFloat(b, 10));
			}), d = getStatsDisplay(idx, min);

		}
		$("#min th:nth-child(" + idx + ")").html(d);
	});
}

function getStatsDisplay(idx, value) {

	var cur = idx == 8 ? "SGD" : $("#based option:selected").val();

	var d = (idx == 5 || idx == 6) ? value : toCurrency(value, cur);
	return d;

}