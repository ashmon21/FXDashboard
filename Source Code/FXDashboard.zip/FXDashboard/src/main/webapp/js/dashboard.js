var get_link = "getDashboardData";

$(document).ready(function() {
	Highcharts.setOptions({
		lang : {
			thousandsSep : ','
		}
	});

	filterTransactionRatesChart();
	initMarketRatesChart();
	initVolumeChart();
});

function filterTransactionRatesChart() {
	var b = $("#trans_based option:selected").val(), w = $(
			"#trans_wanted option:selected").val(), c = $(
			"#trans_type option:selected").val();

	initTransactionRatesChart(b, w, c);
}

function filterMarketRatesChart() {
	var b = $("#rates_based option:selected").val(), w = $(
			"#rates_wanted option:selected").val(), link = get_link
			+ "?type=market_rates_chart", load = false;

	if (b != "0") {
		link += "&based=" + b;
		load = true;
	}

	if (w != "0") {
		link += "&wanted=" + w;
		load = true;
	}

	if (load) {
		initMarketRatesChart(link);
	}
}

function resetMarketRatesChart() {
	initMarketRatesChart();
	$("#rates_based").val("0");
	$("#rates_wanted").val("0");
}

function resetTransactionRatesChart() {
	initTransactionRatesChart("SGD", "USD", "INDIVIDUAL");
	$("#trans_based").val("SGD");
	$("#trans_wanted").val("USD");
	$("#trans_type").val("INDIVIDUAL");
}

function initMarketRatesChart(link) {

	if (!link)
		link = get_link + "?type=market_rates_chart";

	$.get(link, function(data) {
		drawMarketRatesChart(data);
	}).fail(function() {
		alert("Error getting data from server.");
	});
}

function initTransactionRatesChart(b, w, c) {

	$.get(get_link, {
		type : "transactions_rates_chart",
		based : b,
		wanted : w,
		clientType : c
	}, function(data) {
		drawTransactionRatesChart(data, b, w, c);
	}).fail(function() {
		alert("Error getting data from server.");
	});
}

function drawTransactionRatesChart(data, b, w, c) {
	var rates = data["rates"], transactions = data["transactions"], time_arr = [];

	if (rates != undefined && transactions != undefined) {
		$.each(rates, function(a, b) {
			if ($.inArray(b[0], time_arr) < 0) {
				time_arr.push(b[0]);
			}
		});

		$.each(transactions, function(a, b) {
			if ($.inArray(b[0], time_arr) < 0) {
				time_arr.push(b[0]);
			}
		});
	}

	$('#transactions_rates_chart')
			.highcharts(
					{
						chart : {
							zoomType : 'xy',
							panning : true,
							panKey : 'shift'
						},
						title : {
							text : b + '-' + w
									+ ': Transactions and Market Rates For '
									+ c + ' clients'
						},
						subtitle : {
							text : 'Click and Drag to zoom in. Hold down the SHIFT key to pan across the chart'
						},
						xAxis : [ {
							type : 'datetime',
							tickInterval : 1800 * 1000, // half an hour interval
							max : Math.max.apply(Math, time_arr),
							min : Math.min.apply(Math, time_arr),
							dateTimeLabelFormats : {
								hour : '%H:%M',
								day : '%H:%M',
							},
							crosshair : true
						} ],
						yAxis : [
								{ // Primary yAxis
									labels : {
										format : '{value}',
										style : {
											color : Highcharts.getOptions().colors[1]
										}
									},
									title : {
										text : 'Market Rate',
										style : {
											color : Highcharts.getOptions().colors[1]
										}
									}
								},
								{ // Secondary yAxis
									title : {
										text : 'Base Transaction Amount',
										style : {
											color : Highcharts.getOptions().colors[0]
										}
									},
									labels : {
										formatter : function() {
											return Highcharts.numberFormat(
													this.value, 0)
													+ ' ' + b;
										},
										style : {
											color : Highcharts.getOptions().colors[0]
										}
									},
									opposite : true
								} ],
						tooltip : {
							shared : true
						},
						legend : {
							layout : 'vertical',
							align : 'left',
							x : 120,
							verticalAlign : 'top',
							y : 100,
							floating : true,
							backgroundColor : (Highcharts.theme && Highcharts.theme.legendBackgroundColor)
									|| '#FFFFFF'
						},
						series : [ {
							name : 'Transaction Amount',
							type : 'column',
							yAxis : 1,
							data : transactions,
							tooltip : {
								valueSuffix : ' ' + b
							}
						}, {
							name : 'Market Rate',
							type : 'line',
							data : rates
						} ]
					});
}

function drawMarketRatesChart(data) {

	var time_arr = [], rates = [];

	$.each(data, function(i, row) {
		var r = {
			name : i,
			data : row
		};
		rates.push(r);

		$.each(row, function(a, b) {
			if ($.inArray(b[0], time_arr) < 0) {
				time_arr.push(b[0]);
			}
		});
	});

	$('#market_rates_chart')
			.highcharts(
					{
						chart : {
							type : 'line',
							zoomType : 'x',
							panning : true,
							panKey : 'shift'
						},
						title : {
							text : 'Market Rate Trends'
						},
						subtitle : {
							text : 'Click and Drag to zoom in. Hold down the SHIFT key to pan across the chart'
						},
						xAxis : {
							title : {
								text : 'Time in hh:mm'
							},
							type : 'datetime',
							tickInterval : 1800 * 1000, // half an hour interval
							max : Math.max.apply(Math, time_arr),
							min : Math.min.apply(Math, time_arr),
							dateTimeLabelFormats : {
								hour : '%H:%M',
								day : '%H:%M',
							}
						},
						yAxis : {
							title : {
								text : 'Market Rate'
							}
						},
						series : rates
					});

}

function initVolumeChart() {
	$.get(get_link, {
		type : "transactions_volume_chart"
	}, function(d) {
		getVolumeChart(d);
	}).fail(function() {
		alert("Error getting data from server.");
	});
}

function getVolumeChart(data) {
	var based_arr = [], drill_arr = [], type_arr = [];

	$.each(data, function(i, row) {

		var found = false;

		$.each(based_arr, function(j, o) {
			if (o.name === row[0]) {
				o.y = o.y + row[3];
				found = true;
			}
		});

		if (!found) {
			var obj = {
				name : row[0],
				y : row[3],
				drilldown : row[0]
			};

			based_arr.push(obj);
		}
	});

	$.each(data, function(i, row) {

		var dd = {
			name : row[1],
			y : row[3],
			drilldown : row[0] + "_" + row[1]
		}, found = false;

		$.each(drill_arr, function(j, o) {
			if (o.id === row[0]) {
				var new_dd = true;
				$.each(o.data, function(x, y) {
					if (y.drilldown == row[0] + "_" + row[1]) {
						y.y = y.y + row[3];
						new_dd = false;
					}
				});

				if (new_dd) {
					o.data.push(dd);
				}

				found = true;
			}
		});

		if (!found) {
			var obj = {
				name : 'From ' + row[0],
				id : row[0],
				data : [ dd ]
			};

			drill_arr.push(obj);
		}
	});

	$.each(data, function(i, row) {
		var id = row[0] + "_" + row[1], dd = [ row[2], row[3] ], found = false;

		$.each(drill_arr, function(j, o) {
			if (o.id === id) {
				o.data.push(dd);
				found = true;
			}
		});

		if (!found) {
			var obj = {
				name : row[0] + "-" + row[1],
				id : id,
				data : [ dd ]
			};

			drill_arr.push(obj);
		}
	});

	drawVolumeChart(based_arr, drill_arr);

}

function drawVolumeChart(based_arr, drill_arr) {
	$('#volume_chart')
			.highcharts(
					{
						chart : {
							type : 'pie'
						},
						title : {
							text : 'Number of Transactions [Based Currency]'
						},
						subtitle : {
							text : 'Click the slices to view details.'
						},
						plotOptions : {
							series : {
								dataLabels : {
									enabled : true,
									format : '{point.name}: {point.y} trades'
								}
							}
						},

						tooltip : {
							headerFormat : '<span style="font-size:11px">{series.name}</span><br>',
							pointFormat : '<span style="color:{point.color}">{point.name}: {point.y} trades</span><br>'
						},
						series : [ {
							name : 'Based Currency',
							colorByPoint : true,
							data : based_arr
						} ],
						drilldown : {
							series : drill_arr
						}
					});
}