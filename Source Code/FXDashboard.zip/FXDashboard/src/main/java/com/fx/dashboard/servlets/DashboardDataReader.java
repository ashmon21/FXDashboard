package com.fx.dashboard.servlets;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fx.constants.ClientType;
import com.fx.constants.Currency;
import com.fx.model.MarketRate;
import com.fx.model.Transaction;
import com.fx.util.PropertiesUtil;
import com.fx.util.RatesReader;
import com.fx.util.TransactionsReader;
import com.google.gson.Gson;

public class DashboardDataReader extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private Gson gson;

	private Properties properties;

	private RatesReader rates_reader;

	private TransactionsReader transacations_reader;

	private final static String TRANSACTION_FILE = "transaction_file";

	private final static String MARKET_RATE_FILE = "market_rate_file";

	private enum request_type {
		market_rates_chart, transactions_rates_chart, transactions_volume_chart
	};

	public void init() {
		properties = PropertiesUtil.loadPropertiesFromFile();
		gson = new Gson();
		rates_reader = new RatesReader();
		transacations_reader = new TransactionsReader();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

		Currency based = request.getParameterMap().containsKey("based")
				? Currency.valueOf(request.getParameter("based")) : null;

		Currency wanted = request.getParameterMap().containsKey("wanted")
				? Currency.valueOf(request.getParameter("wanted")) : null;

		ClientType clientType = request.getParameterMap().containsKey("clientType")
				? ClientType.valueOf(request.getParameter("clientType")) : null;

		response.setContentType("application/json");

		if (request_type.market_rates_chart.toString().equalsIgnoreCase(request.getParameter("type"))) {

			response.getWriter().write(getMarketRateChartData(based, wanted));
		}

		if (request_type.transactions_rates_chart.toString().equalsIgnoreCase(request.getParameter("type"))) {

			response.getWriter().write(getTransactionRateChartData(based, wanted, clientType));
		}

		if (request_type.transactions_volume_chart.toString().equalsIgnoreCase(request.getParameter("type"))) {

			response.getWriter().write(getTransactionVolumeChartData());
		}

	}

	private String getTransactionVolumeChartData() {

		List<Object[]> json_list = new ArrayList<>();

		List<Transaction> transactions = transacations_reader
				.getTransactionsFromCSV(properties.getProperty(TRANSACTION_FILE));

		Map<String, Transaction> filtered_map = new HashMap<>();

		transactions.forEach(t -> {
			String key = t.getBasedCurrency() + "," + t.getWantedCurrency() + "," + t.getClientType();
			if (!filtered_map.containsKey(key)) {
				filtered_map.put(key, t);
			}
		});

		filtered_map.forEach((key, val) -> {
			long count = transactions.stream()
					.filter(t -> t.getBasedCurrency().equals(val.getBasedCurrency())
							&& t.getWantedCurrency().equals(val.getWantedCurrency())
							&& t.getClientType().equals(val.getClientType()))
					.count();

			json_list.add(new Object[] { val.getBasedCurrency(), val.getWantedCurrency(), val.getClientType(), count });

		});

		return gson.toJson(json_list);
	}

	private String getTransactionRateChartData(Currency based, Currency wanted, ClientType clientType) {

		Map<String, List<Object[]>> json_map = new HashMap<>();

		if (based != null && wanted != null && clientType != null) {

			String rates_key = "rates";
			String transactions_key = "transactions";

			List<MarketRate> rates = rates_reader.getMarketRatesFromCSV(properties.getProperty(MARKET_RATE_FILE));
			rates.forEach(r -> {
				if (based.equals(r.getBasedCurrency()) && wanted.equals(r.getWantedCurrency())) {
					List<Object[]> l = json_map.containsKey(rates_key) ? json_map.get(rates_key) : new ArrayList<>();
					l.add(new Object[] { getTimeinLong(r.getExpiryTime()), r.getRate() });
					json_map.put(rates_key, l);
				}
			});

			List<Transaction> transactions = transacations_reader
					.getTransactionsFromCSV(properties.getProperty(TRANSACTION_FILE));
			transactions.forEach(t -> {

				if (based.equals(t.getBasedCurrency()) && wanted.equals(t.getWantedCurrency())
						&& clientType.equals(t.getClientType())) {
					List<Object[]> l = json_map.containsKey(transactions_key) ? json_map.get(transactions_key)
							: new ArrayList<>();
					l.add(new Object[] { getTimeinLong(t.getTransactionTime()), t.getBasedCurrencyAmount() });
					json_map.put(transactions_key, l);
				}
			});
		}

		return gson.toJson(json_map);
	}

	private long getTimeinLong(LocalTime time) {
		LocalDateTime dt = LocalDateTime.of(LocalDate.now(), time);
		Instant instant = dt.toInstant(ZoneOffset.UTC);
		Date date = Date.from(instant);
		return date.getTime();
	}

	private String getMarketRateChartData(Currency based, Currency wanted) {

		Map<String, List<Object[]>> json_map = new HashMap<>();

		List<MarketRate> rates = rates_reader.getMarketRatesFromCSV(properties.getProperty(MARKET_RATE_FILE));
		rates.forEach(r -> {

			boolean isCorrectRecord = (based == null || based.equals(r.getBasedCurrency()))
					&& (wanted == null || wanted.equals(r.getWantedCurrency()));

			if (isCorrectRecord) {
				String cur = r.getBasedCurrency().toString() + "-" + r.getWantedCurrency().toString();

				List<Object[]> l = json_map.containsKey(cur) ? json_map.get(cur) : new ArrayList<>();
				l.add(new Object[] { getTimeinLong(r.getExpiryTime()), r.getRate() });

				json_map.put(cur, l);
			}
		});
		return gson.toJson(json_map);
	}

}
