package com.fx.dashboard.util;

import java.net.InetAddress;

import org.eclipse.jetty.server.Connector;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.webapp.WebAppContext;

public class FXDashboardApp {

	public static void main(String[] args) throws Exception {

		Server server = new Server();

		String port = System.getProperty("port");
		if (port == null || port.isEmpty()) {
			port = "8080";
		}

		String context = "/";

		ServerConnector connector = new ServerConnector(server);
		connector.setPort(Integer.valueOf(port));

		server.setConnectors(new Connector[] { connector });

		ContextHandlerCollection contexts = new ContextHandlerCollection();

		String webappDir = "src/main/webapp/";
		String war = System.getProperty("war_file");

		WebAppContext webapp = new WebAppContext();

		if (war != null && !war.isEmpty()) {
			webapp.setWar(war);
		} else {
			webapp.setDescriptor(webappDir + "/WEB-INF/web.xml");
			webapp.setDefaultsDescriptor(webappDir + "/WEB-INF/webdefault.xml");
			webapp.setResourceBase(webappDir);
		}
		webapp.setContextPath(context);

		/****** JSP SUPPORT ADD TO JETTY ****/
		org.eclipse.jetty.webapp.Configuration.ClassList classlist = org.eclipse.jetty.webapp.Configuration.ClassList
				.setServerDefault(server);
		classlist.addBefore("org.eclipse.jetty.webapp.JettyWebXmlConfiguration",
				"org.eclipse.jetty.annotations.AnnotationConfiguration");
		webapp.setAttribute("org.eclipse.jetty.server.webapp.ContainerIncludeJarPattern",
				".*/[^/]*servlet-api-[^/]*\\.jar$|.*/javax.servlet.jsp.jstl-.*\\.jar$|.*/[^/]*taglibs.*\\.jar$");
		/*********************************/

		contexts.setHandlers(new Handler[] { webapp });
		server.setHandler(contexts);

		server.start();
		String url = "http://" + InetAddress.getLocalHost().getCanonicalHostName().toLowerCase() + ":" + port + context;
		System.out.println("The web application is started at: " + url);
		System.out.println("Enter [E] to gracefully shut down the application");
		while (true) {
			char c = (char) System.in.read();
			if (c == 'E') {
				System.exit(0);
			}
		}
	}

}
