package com.fx.dashboard.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fx.constants.Currency;
import com.fx.util.CSVUtil;
import com.fx.util.PropertiesUtil;
import com.google.gson.Gson;

public class BlotterDataReader extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private final static String REPORT_FILE = "report_file";

	private Gson gson;

	private Properties properties;

	private Logger logger = Logger.getLogger(BlotterDataReader.class.getName());

	public void init() {
		properties = PropertiesUtil.loadPropertiesFromFile();
		gson = new Gson();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

		Currency based = Currency.valueOf(request.getParameter("based"));
		
		List<String> wanted_currencies = Arrays.asList(request.getParameter("wanted").split(","));

		String file = properties.getProperty(REPORT_FILE);
		List<String> rows = new ArrayList<String>();

		try {
			rows = CSVUtil.getRowsFromCSV(file);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Error getting rows from " + file);
		}

		List<String[]> json_arr = new ArrayList<String[]>();

		rows.forEach(r -> {
			String[] arr = ("," + r).split(",");
			
			Currency b = Currency.getValueOf(arr[1]);
			Currency w = Currency.getValueOf(arr[2]);

			if (b != null && b.equals(based)) {
				if (w != null && wanted_currencies.contains(w.toString())) {
					json_arr.add(arr);
				}
			}

		});

		response.setContentType("application/json");
		response.getWriter().write(gson.toJson(json_arr.toArray()));
	}
}
